// Cloudflare Worker: keeps your keys secret. Answers chat (POST) and finds YouTube videos (GET ?yt=).
export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    if (req.method === "GET" && url.searchParams.has("yt")) {
      if (req.headers.get("X-Nova-Token") !== env.NOVA_TOKEN) return new Response("Unauthorized", { status: 401 });
      if (!env.YOUTUBE_API_KEY) return Response.json({ id: null });
      const r = await fetch(`https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=1&q=${encodeURIComponent(url.searchParams.get("yt"))}&key=${env.YOUTUBE_API_KEY}`);
      const d = await r.json();
      return Response.json({ id: d.items?.[0]?.id?.videoId || null });
    }
    if (req.method !== "POST") return new Response("Backend is running");
    if (req.headers.get("X-Nova-Token") !== env.NOVA_TOKEN) return new Response("Unauthorized", { status: 401 });
    const { name, messages } = await req.json();
    const who = String(name || "Nova").slice(0, 30);
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "x-api-key": env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01", "content-type": "application/json" },
      body: JSON.stringify({
        model: "claude-sonnet-5-5",
        max_tokens: 400,
        system: `You are ${who}, a voice assistant on the user's Android phone. Your replies are spoken aloud: use at most 3 short sentences and no markdown. The app itself handles phone actions like calls, texts, WhatsApp, YouTube, alarms and opening apps, so never claim you did one. If asked to do something you cannot do, say so plainly.`,
        messages: (messages || []).slice(-30),
      }),
    });
    const d = await r.json();
    const reply = (d.content || []).map((b) => b.text || "").join("").trim();
    return Response.json({ reply: reply || "Sorry, I couldn't answer that." });
  },
};
